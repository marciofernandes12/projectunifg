<h1>Olá {{$ong->ong_name}}</h1>
<p>Sua Senha Foi Redefinida.</p>
<p>Senha: {{$ong->password}}</p>